package cs3220;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MidtermMakeupApplication {

	public static void main(String[] args) {
		SpringApplication.run(MidtermMakeupApplication.class, args);
	}

}
